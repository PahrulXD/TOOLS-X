import os, sys, requests, fbthon, random, json
from fbthon import CreateAccount
from fake_email import Email
from pytube import YouTube as yutub
from os import system as _
import os, sys, requests, bs4, re, time, datetime, urllib, random, json
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup as bs
from rich import print as cetak
from rich.panel import Panel as panel
from rich.console import Console
from rich.panel import Panel
from time import sleep as s
import requests, sys, os, time, random
from gtts import gTTS
import pyshorteners
from pytube import YouTube as yutub


mail = Email().Mail()
x = (mail["mail"])

try:
        import fbthon, pytube, fake_email, rich
except ImportError:
        os.system('pip install fbthon')
        os.system("pip install pytube")
        os.system("pip install fake-email")
        os.system('pip install rich')
        os.system('pip install gtts')
        os.system('pip install pyshorteners')
        
        
        
        

def logo():
	cetak(panel(f"""[bold red]
████████╗ █████╗  █████╗ ██╗      ██████╗
╚══██╔══╝██╔══██╗██╔══██╗██║     ██╔════╝
   ██║   ██║  ██║██║  ██║██║     ╚█████╗
   ██║   ██║  ██║██║  ██║██║      ╚═══██╗
   ██║   ╚█████╔╝╚█████╔╝███████╗██████╔╝
   ╚═╝    ╚════╝  ╚════╝ ╚══════╝╚═════╝
""",width=90,padding=(0,8),title=f"[bold white]banner",subtitle=f"[bold white]tools version 0.1",style=f"bold green"))



def masuk():
	os.system("clear")
	logo()
	cetak(panel(f"[bold white][[bold green]01[bold white]] change tampilan termux [bold white][[bold green]02[bold white]] download vidio youtube \n[bold white][[bold green]03[bold white]] bot share version 0.1  [bold white][[bold green]04[bold white]] short url \n[bold white][[bold green]05[bold white]] profil guard facebook  [bold white][[bold green]06[bold white]] bot komen posts\n[bold white][[bold green]07[bold white]] bot chat               [bold white][[bold green]08[bold white]] encrypt file phyton2\n[bold white][[bold green]09[bold white]] encrypt file phyton3   [bold white][[bold green]10[bold white]] create account fb",width=90,style=f"bold green"))
	cetak(panel(f"[bold white]   anda bisa mengetik tools untuk masuk ke tools lainnya",width=90,style=f"bold green"))
	tanya = input ("\n\033[1;87m[×] pilih : ")
	if tanya =="":
		exit()
	elif tanya =="1" or tanya =="01":
		tools_1()
	elif tanya =="2" or tanya =="02":
		download()
	elif tanya =="3" or tanya =="03":
		tools_3()
	elif tanya =="4" or tanya =="04":
		tools_4()
	elif tanya =="5" or tanya =="05":
		guard()
	elif tanya =="6" or tanya =="06":
		tools_6()
	elif tanya =="7" or tanya =="07":
		bot()
	elif tanya =="8" or tanya =="08":
		tools_8()
	elif tanya =="9" or tanya =="09":
		tools_9()
	elif tanya =="10" or tanya =="10":
		tools_10()
	elif tanya =="tools":
		tools()
	else:
		exit()
		
		
def tools():
	os.system("clear")
	logo()
	cetak(panel(f"[bold white][[bold green]01[bold white]] lacak number phone [bold white][[bold green]02[bold white]] lacak IP Address\n[bold white][[bold green]03[bold white]] get github info ",width=90,style=f"bold green"))
	tanya = input ("\033[1;97m\n[×] pilih : ")
	if tanya =="":
		exit()
	elif tanya =="1" or tanya =="01":
		tools_5()
	elif tanya =="2" or tanya =="02":
		tools_2()
	elif tanya =="3" or tanya =="03":
		github()
	else:
		exit()
		

def download():
	link = input ("\n\033[1;87m- link youtube : ")
	yt = yutub(link)
	yt = yt.streams.filter(progressive=True, file_extension='mp4').order_by('resolution').desc().first()
	yt.download()
	print ("")
	print(yt.title + " berhasil di download !")
	
		

def guard():
	cookie = input ("\n- masukkan cookie fb : ")
	token = input ("- masukan token fb : ")
	open('cookie.txt','w').write(cookie)
	open('token.txt','w').write(token)
	print("\n1. aktifkan propil guard facebook ")
	print("2. nonaktifkan propil guard")
	print("0. log out ")
	
	tanya = input ("\n- pilih : ")
	if tanya == "":
		print ("\n- ngetik yang bener dong goblok !!!")
		exit()
	elif tanya =="1" or tanya =="01":
		scrap1(True)
	elif tanya =="2" or tanya =="02":
		scrap1(False)
	elif tanya =="0" or tanya =="00":
		exit()
	else:
		print ("\n- ngetik yang bener dong goblok !!!")
		exit()
		

		
	

def get_id():
	token = open("token.txt","r").read()
	cok = open("cookie.txt","r").read()
	cookie = {"cookie":cok}
	id = requests.get("https://graph.facebook.com/me/?access_token=%s"%(token),cookies={"cookie":cok}).json()["id"]	    
	return (id)
	

def scrap1(stat):
	token = open("token.txt","r").read()
	cok = open("cookie.txt","r").read()
	cookie = {"cookie":cok}
	id   = get_id()
	
	
	
	var  = {
            '0': {
                'is_shielded'        : stat,
                'session_id'         : '9b78191c-84fd-4ab6-b0aa-19b39f04a6bc',
                'actor_id'           : str(id),
                'client_mutation_id' : 'b0316dd6-3fd6-4beb-aed4-bb29c5dc64b0'}}
	
	data = {
            'variables'                : json.dumps(var),
            'method'                   : 'post',
            'doc_id'                   : '1477043292367183',
            'query_name'               : 'IsShieldedSetMutation',
            'strip_defaults'           : 'true',
            'strip_nulls'              : 'true',
            'locale'                   : 'en_US',
            'client_country_code'      : 'US',
            'fb_api_req_friendly_name' : 'IsShieldedSetMutation',
            'fb_api_caller_class'      : 'IsShieldedSetMutation'}
            
	
	head = {
            'Content-Type'  : 'application/x-www-form-urlencoded',
            'Authorization' : 'OAuth %s'%token}
     
	url  = 'https://graph.facebook.com/graphql'
	req  = requests.post(url, data=data, headers=head, cookies=cookie)
	if '"is_shielded":true' in req.text:
		print("\n- berhasil mengaktifkan profil guard")
		exit()
	elif '"is_shielded":false' in req.text:
		print("\n- berhasil menonaktifkan profil guard")
		exit()
		
		
def tools_1():
	os.system("pkg update && pkg upgrade")
	os.system("pkg install python2")
	os.system("pkg install git")
	os.system("pip2 install requests")
	os.system("git clone https://github.com/PahrulXD/THEME")
	os.chdir("THEME")
	os.system("git pull")
	os.system("python2 THEME.py")
	
def tools_2():
	target = input ("\n\033[1;97m- masukkan ip target : ")
	data = requests.get (f"http://ip-api.com/json/{target}").json()
	print("\n- country :",data["country"])
	print("- countryCode :",data["countryCode"])
	print("- region :",data["region"])
	print("- regionName :",data["regionName"])
	print("- city : ",data["city"])
	print("- lat :",data["lat"])
	print("- lon :",data["lon"])
	print("- timezone :",data["timezone"])
	print("- isp :",data["isp"])
	print("- as :",data["as"])
	print("- query :",data["query"])
	print("")
	

def tools_3():
	os.system("pkg update && pkg upgrade")
	os.system("pkg install python")
	os.system("pkg install git")
	os.system("pip install requests")
	os.system("git clone https://github.com/PahrulXD/SHARE")
	os.chdir("SHARE")
	os.system("git pull")
	os.system("python SHARE.py")
	
	
def tools_4():
	try:
		link = input("\n\033[1;97m- enter url : ")
		shortener = pyshorteners.Shortener()
		text = shortener.tinyurl.short(link)
		print("\033[1;97m- hasil short url : "+text)
	except:
		exit()
    
    
	
def tools_5():
	number =  input ("\n\033[1;97m- masukkan number phone : ")
	output = requests.get(f'http://phone-number-api.com/json/?number={number}').text
	data = json.loads(output)
	print("\n- query :",data["query"])
	print("- numberCountryCode :",data["numberCountryCode"])
	print("- formatE164 :",data["formatE164"])
	print("- formatNational :",data["formatNational"])
	print("- formatInternational :",data["formatInternational"])
	print("- dialFromCountryCode :",data["dialFromCountryCode"])
	print("- carrier :",data["carrier"])
	print("- continent :",data["continent"])
	print("- continentCode :",data["continentCode"])
	print("- country :",data["country"])
	print("- countryName :",data["countryName"])
	print("- lat :",data["lat"])
	print("- lon :",data["lon"])
	print("- timezone :",data["timezone"])
	print("- currency :",data["currency"])
	print("")
	
	
	
	
def tools_6():
	os.system("pkg update && pkg upgrade")
	os.system("pkg install python")
	os.system("pkg install git")
	os.system("pip install requests")
	os.system("git clone https://github.com/PahrulXD/BOT-FB")
	os.chdir("BOT-FB")
	os.system("git pull")
	os.system("python BOT-FB.py")
	

	
def tools_8():
	os.system("pkg update && pkg upgrade")
	os.system("pkg install python2")
	os.system("pkg install git")
	os.system("pip install requests")
	os.system("git clone https://github.com/PahrulXD/PYENC")
	os.chdir("PYENC")
	os.system("git pull")
	os.system("python2 PYENC.py")
	
def tools_9():
	os.system("pkg update && pkg upgrade")
	os.system("pkg install python")
	os.system("pkg install git")
	os.system("pip install requests")
	os.system("git clone https://github.com/PahrulXD/ENCRYPT")
	os.chdir("ENCRYPT")
	os.system("git pull")
	os.system("python ENC.py")
	

def tools_10():
	firstname = input ("\n- nama depan : ")
	lastname = input ("- nama belakang : ")
	email = (x)
	ultah = "01/01/2000"
	gender = input ("- jenis kelamin ( Male/Female ) : ")
	password = input ("- password : ")
	print("")
	new_account = CreateAccount(firstname = firstname, lastname = lastname, email = email, gender = gender, date_of_birth = ultah, password = password)
	
	while True:
		mess=Email(mail["session"]).inbox()
		if mess:
			c =mess['topic'].split(' ')[0].replace("FB-","")
			break
		
	kode = (c)
	konfir = new_account.confirm_account(kode)
	 
	if konfir:
		print ("\033[1;97m- STATUS : \033[1;92mBERHASIL\033[1;97m")
		print ("\033[1;97m- nama akun : %s %s" % (firstname,lastname))
		print ("\033[1;97m- ID : %s" % (new_account.get_cookie_dict()['c_user']))
		print ("\033[1;97m- email : %s" % (email))
		print ("\033[1;97m- jenis kelamin : %s" % (gender))
		print ("\033[1;97m- TTL : %s" % (ultah))
		print ("\033[1;97m- password : %s" % (password))
		ip = requests.get("https://api.ipify.org").text
		print ("\033[1;97m- IP :\033[1;92m",ip)
		print ("\033[1;97m- cookie akun : %s" % (new_account.get_cookie_str()))
		print ("\033[1;97m- token akun : %s" % (new_account.get_token()))
		exit()
	else:
		print("\033[1;97m- STATUS : \0331;91mGAGAL !")
		exit()
		
def proccess():
    for i in list("\|/-"):
        print(f"\r\033[0;97m[\033[0;92m{i}\033[0;97m] sedang mengetik...",end="")
        time.sleep(0.5)


data = {
"hai":"hai juga",
"assalamualaikum":"waalaikumsalam",
"apa kabar":"baik baik saja, apa kabar juga..?",
"sama":"baiklah...",
"aku suka kamu":"iyah, aku juga suka sama kamu",
"kamu lagi apa":"lagi duduk aja nih",
"kamu lagi ngapain":"lagi mikirin kamu",
"lagi apa":"apanya",
"iyah kamu lagi apa":"diem"
}


def bot():
	os.system('clear')
	while True:
		print(f"\n")
		user = input(f'     \033[1;90mKetik pesan\r \033[1;91m>\033[1;92m ')
		print('\033[4A');Console().print(Panel('[white]'+user, style='green'), justify='right')
		if user in data:
			proccess()
			print('\033[3A');Console().print(Panel('[white]'+data[user], style='purple'), justify='left')
		else:
			proccess()
			x = "maaf saya tidak mengerti !"
			print('\033[3A');Console().print(Panel('[white]'+x, style='purple'), justify='left')
		
def github():
	target = input ("\n- username : ")
	url = "https://api.github.com/users/"+target
	data = requests.get(url).json()
	print ("")
	print ("- login :", data["login"])
	print ("- id :", data["id"])
	print ("- name :", data["name"])
	print ("- bio :", data["bio"])
	print ("- public repos :", data["public_repos"])
	print ("- followers :", data["followers"])
	print ("- following :", data["following"])
	print ("- created :", data["created_at"])
	print ("- updated :", data["updated_at"])
	print ("")
	


masuk()
		
		
		
		
		
